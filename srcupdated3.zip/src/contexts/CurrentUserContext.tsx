"use client";

import {
  createContext,
  useContext,
} from "react";

import { UserRole } from "@/constants/userRoles";

export type CurrentUser = {
  name: string;
  email: string;
  role: UserRole;
};

type CurrentUserContextValue = {
  user: CurrentUser;
  isAdmin: boolean;
};

const CurrentUserContext =
  createContext<CurrentUserContextValue | null>(
    null
  );

type CurrentUserProviderProps = {
  children: React.ReactNode;
  user: CurrentUser;
};

export function CurrentUserProvider({
  children,
  user,
}: CurrentUserProviderProps) {
  return (
    <CurrentUserContext.Provider
      value={{
        user,
        isAdmin: user.role === "Admin",
      }}
    >
      {children}
    </CurrentUserContext.Provider>
  );
}

export function useCurrentUser() {
  const context = useContext(
    CurrentUserContext
  );

  if (!context) {
    throw new Error(
      "useCurrentUser must be used inside CurrentUserProvider."
    );
  }

  return context;
}